from aiogram.fsm.state import State, StatesGroup

class TarotReading(StatesGroup):
    waiting_for_question = State()

