import asyncio
from aiogram import Bot, Dispatcher
from bot.handlers.tarot import oracle
from bot.handlers import start
from bot.config import BOT_TOKEN
from bot.keyboards import main_menu
from bot.handlers import common
from bot.handlers.advice import sugest


async def main():
    bot = Bot(token=BOT_TOKEN)
    dp = Dispatcher()

    # Подключаем роутеры
    dp.include_routers(
        oracle.router,
        start.router,
        main_menu.router,
        common.router,
        sugest.router,
    )

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())