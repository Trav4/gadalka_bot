from geopy.geocoders import Nominatim

async def get_coordinates(city_name):
    geolocator = Nominatim(user_agent="natal_chart_bot")
    location = geolocator.geocode(city_name)
    if location:
        return location.latitude, location.longitude
    return None, None
