import random


# Список всех карт
TAROT_CARDS = [
    "0_the_fool.jpg", "1_the_magician.jpg", "2_the_high_priestess.jpg",
    "3_the_empress.jpg", "4_the_emperor.jpg", "5_the_hierophant.jpg",
    "6_the_lovers.jpg", "7_the_chariot.jpg", "8_strength.jpg",
    "9_the_hermit.jpg", "10_wheel_of_fortune.jpg", "11_justice.jpg",
    "12_the_hanged_man.jpg", "13_death.jpg", "14_temperance.jpg",
    "15_the_devil.jpg", "16_the_tower.jpg", "17_the_star.jpg",
    "18_the_moon.jpg", "19_the_sun.jpg", "20_judgement.jpg", "21_the_world.jpg",
    "22_ace_of_wands.jpg", "23_two_of_wands.jpg", "24_three_of_wands.jpg",
    "25_four_of_wands.jpg", "26_five_of_wands.jpg", "27_six_of_wands.jpg",
    "28_seven_of_wands.jpg", "29_eight_of_wands.jpg", "30_nine_of_wands.jpg",
    "31_ten_of_wands.jpg", "32_page_of_wands.jpg", "33_knight_of_wands.jpg",
    "34_queen_of_wands.jpg", "35_king_of_wands.jpg", "36_ace_of_cups.jpg",
    "37_two_of_cups.jpg", "38_three_of_cups.jpg", "39_four_of_cups.jpg",
    "40_five_of_cups.jpg", "41_six_of_cups.jpg", "42_seven_of_cups.jpg",
    "43_eight_of_cups.jpg", "44_nine_of_cups.jpg", "45_ten_of_cups.jpg",
    "46_page_of_cups.jpg", "47_knight_of_cups.jpg", "48_queen_of_cups.jpg",
    "49_king_of_cups.jpg", "50_ace_of_swords.jpg", "51_two_of_swords.jpg",
    "52_three_of_swords.jpg", "53_four_of_swords.jpg", "54_five_of_swords.jpg",
    "55_six_of_swords.jpg", "56_seven_of_swords.jpg", "57_eight_of_swords.jpg",
    "58_nine_of_swords.jpg", "59_ten_of_swords.jpg", "60_page_of_swords.jpg",
    "61_knight_of_swords.jpg", "62_queen_of_swords",  "63_king_of_swords",
    "64_ace_of_pentacles",  "65_two_of_pentacles",  "66_three_of_pentacles",
    "67_four_of_pentacles",  "68_five_of_pentacles",  "69_six_of_pentacles",
    "70_seven_of_pentacles",  "71_eight_of_pentacles",  "72_nine_of_pentacles",
    "73_ten_of_pentacles",  "74_page_of_pentacles",  "75_knight_of_pentacles",
    "76_queen_of_pentacles",  "77_king_of_pentacles"
]




 TAROT_CARD_RU ={
    # Старшие арканы
    "0_the_fool.jpg": "Шут",
    "1_the_magician.jpg": "Маг",
    "2_the_high_priestess.jpg": "Верховная Жрица",
    "3_the_empress.jpg": "Императрица",
    "4_the_emperor.jpg": "Император",
    "5_the_hierophant.jpg": "Иерофант",
    "6_the_lovers.jpg": "Влюблённые",
    "7_the_chariot.jpg": "Колесница",
    "8_strength.jpg": "Сила",
    "9_the_hermit.jpg": "Отшельник",
    "10_wheel_of_fortune.jpg": "Колесо Фортуны",
    "11_justice.jpg": "Справедливость",
    "12_the_hanged_man.jpg": "Повешенный",
    "13_death.jpg": "Смерть",
    "14_temperance.jpg": "Умеренность",
    "15_the_devil.jpg": "Дьявол",
    "16_the_tower.jpg": "Башня",
    "17_the_star.jpg": "Звезда",
    "618_the_moon.jpg": "Луна",
    "19_the_sun.jpg": "Солнце",
    "20_judgement.jpg": "Суд",
    "21_the_world.jpg": "Мир",
    "22_ace_of_wands.jpg": "Туз Жезлов",
    "23_two_of_wands.jpg": "Двойка Жезлов",
    "24_three_of_wands.jpg": "Тройка Жезлов",
    "25_four_of_wands.jpg": "Четвёрка Жезлов",
    "26_five_of_wands.jpg": "Пятёрка Жезлов",
    "27_six_of_wands.jpg": "Шестёрка Жезлов",
    "28_seven_of_wands.jpg": "Семёрка Жезлов",
    "29_eight_of_wands.jpg": "Восьмёрка Жезлов",
    "30_nine_of_wands.jpg": "Девятка Жезлов",
    "31_ten_of_wands.jpg": "Десятка Жезлов",
    "32_page_of_wands.jpg": "Паж Жезлов",
    "33_knight_of_wands.jpg": "Рыцарь Жезлов",
    "34_queen_of_wands.jpg": "Королева Жезлов",
    "35_king_of_wands.jpg": "Король Жезлов",
    "36_ace_of_cups.jpg": "Туз Кубков",
    "37_two_of_cups.jpg": "Двойка Кубков",
    "38_three_of_cups.jpg": "Тройка Кубков",
    "39_four_of_cups.jpg": "Четвёрка Кубков",
    "40_five_of_cups.jpg": "Пятёрка Кубков",
    "41_six_of_cups.jpg": "Шестёрка Кубков",
    "42_seven_of_cups.jpg": "Семёрка Кубков",
    "43_eight_of_cups.jpg": "Восьмёрка Кубков",
    "44_nine_of_cups.jpg": "Девятка Кубков",
    "45_ten_of_cups.jpg": "Десятка Кубков",
    "46_page_of_cups.jpg": "Паж Кубков",
    "47_knight_of_cups.jpg": "Рыцарь Кубков",
    "48_queen_of_cups.jpg": "Королева Кубков",
    "49_king_of_cups.jpg": "Король Кубков",
    "50_ace_of_swords.jpg": "Туз Мечей",
    "51_two_of_swords.jpg": "Двойка Мечей",
    "52_three_of_swords.jpg": "Тройка Мечей",
    "53_four_of_swords.jpg": "Четвёрка Мечей",
    "54_five_of_swords.jpg": "Пятёрка Мечей",
    "55_six_of_swords.jpg": "Шестёрка Мечей",
    "56_seven_of_swords.jpg": "Семёрка Мечей",
    "57_eight_of_swords.jpg": "Восьмёрка Мечей",
    "58_nine_of_swords.jpg": "Девятка Мечей",
    "59_ten_of_swords.jpg": "Десятка Мечей",
    "60_page_of_swords.jpg": "Паж Мечей",
    "61_knight_of_swords.jpg": "Рыцарь Мечей",
    "62_queen_of_swords.jpg": "Королева Мечей",
    "63_king_of_swords.jpg": "Король Мечей",
    "64_ace_of_pentacles.jpg": "Туз Пентаклей",
    "65_two_of_pentacles.jpg": "Двойка Пентаклей",
    "66_three_of_pentacles.jpg": "Тройка Пентаклей",
    "67_four_of_pentacles.jpg": "Четвёрка Пентаклей",
    "68_five_of_pentacles.jpg": "Пятёрка Пентаклей",
    "69_six_of_pentacles.jpg": "Шестёрка Пентаклей",
    "70_seven_of_pentacles.jpg": "Семёрка Пентаклей",
    "71_eight_of_pentacles.jpg": "Восьмёрка Пентаклей",
    "72_nine_of_pentacles.jpg": "Девятка Пентаклей",
    "73_ten_of_pentacles.jpg": "Десятка Пентаклей",
    "74_page_of_pentacles.jpg": "Паж Пентаклей",
    "75_knight_of_pentacles.jpg": "Рыцарь Пентаклей",
    "76_queen_of_pentacles.jpg": "Королева Пентаклей",
    "77_king_of_pentacles.jpg": "Король Пентаклей",
}
pass

# Старшие арканы — только первые 22 карты
MAJOR_ARCANA = TAROT_CARDS[:22]

# Младшие арканы — все остальные
MINOR_ARCANA = TAROT_CARDS[22:]

def get_random_major_card():
    """Вернуть случайную карту из старших арканов."""
    return random.choice(MAJOR_ARCANA)

def get_random_card():
    """Вернуть случайную карту из всей колоды."""
    return random.choice(TAROT_CARDS)

def get_random_major_cards(count: int):
    """Вернуть несколько случайных карт из старших арканов (без повторений)."""
    return random.sample(MAJOR_ARCANA, k=count)

def get_random_cards(count: int):
    """Вернуть несколько случайных карт из всей колоды (без повторений)."""
    return random.sample(TAROT_CARDS, k=count)