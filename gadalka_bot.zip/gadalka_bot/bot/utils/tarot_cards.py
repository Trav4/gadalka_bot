
# tarot_cards utils