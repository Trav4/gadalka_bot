from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.utils.keyboard import InlineKeyboardBuilder
from bot.states.sugest_states import DailyAdvice
from bot.services.openai_service import generate_advice_answer

router = Router()

# Клавиатура под ответом
def under_answer_sugest_menu():
    buttons_data = [
        {"text": "🔙 Назад", "callback_data": "sugest_menu"},
        {"text": "🔁 Спросить ещё", "callback_data": "sugest1"},
        {"text": "🏠 Главное меню", "callback_data": "back_to_main_menu"},
    ]

    builder = InlineKeyboardBuilder()
    for button in buttons_data:
        builder.button(text=button["text"], callback_data=button["callback_data"])
    builder.adjust(3)

    return builder.as_markup()
# Клавиатура под ответом
def under_menu():
    buttons_data = [
        {"text": "🔙 Назад", "callback_data": "sugest_menu"},
    ]

    builder = InlineKeyboardBuilder()
    for button in buttons_data:
        builder.button(text=button["text"], callback_data=button["callback_data"])
    builder.adjust(3)

    return builder.as_markup()


# Обработка кнопки "Спросить совет"
@router.callback_query(F.data == "sugest1")
async def daily_advice_start(callback: CallbackQuery, state: FSMContext):
    await state.update_data(advice_type="daily")  # Сохраняем тип совета
    await state.set_state(DailyAdvice.waiting_for_question)  # Ожидаем вопрос
    print(f"📥 Пользователь {callback.from_user.id} начал совет")

    await callback.message.edit_text(
        "О, странник под звёздным сводом…\n\n"
                "Ты вошёл в пространство ТУММИМ — той, что слышит сквозь молчание,\n"                
                "Здесь нет случайностей. Если ты читаешь эти строки — значит, время пришло.\n"
                "Ты стоишь на пороге перемен, и Вселенная ждёт, когда ты сделаешь шаг\n\n"                
                "Попроси совета — и я дам тебе не просто ответ, но откровение, что озарит твой путь.",
    parse_mode = "Markdown",
    reply_markup = under_menu()
    )
    await callback.answer()

# Ожидаем вопрос пользователя
@router.message(DailyAdvice.waiting_for_question)
async def daily_advice_continue(message: Message, state: FSMContext):
    data = await state.get_data()
    user_question = message.text

    await message.answer("✨ Мудрые силы собираются для ответа... 🔮")

    # Получаем совет от ChatGPT через OpenAI
    response = await generate_advice_answer(user_question)

    await message.answer(
        f"🔮 *Ответ ТУММИМ:*{response}",
        parse_mode="Markdown",
        reply_markup=under_answer_sugest_menu()
    )

    await state.clear()

    # # Обработка включения/выключения автоматической рассылки
    # @router.callback_query(F.data == "sugets2")
    # async def toggle_daily_prediction(callback: CallbackQuery):
    #     user_id = callback.from_user.id
    #     current_status = user_daily_toggle.get(user_id, False)
    #     user_daily_toggle[user_id] = not current_status  # Переключение состояния
    #
    #     status_text = "включена ✅" if user_daily_toggle[user_id] else "отключена ❌"
    #
    #     await callback.message.edit_text(
    #         f"📜 Автоматическая отправка персонального наставления {status_text}.",
    #         reply_markup=under_answer_sugest_menu()
    #     )
    #     await callback.answer()
