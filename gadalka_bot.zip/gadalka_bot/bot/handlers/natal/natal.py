# advice.py
from aiogram import Router

router = Router()

# Здесь вы можете регистрировать обработчики событий
# Например:
# отобразить маршрут, если он потребуется в будущем
router.message.register(lambda x: None, lambda x: x.text == "example text")