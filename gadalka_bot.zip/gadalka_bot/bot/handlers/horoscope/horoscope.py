from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from bot.keyboards.main_menu import horoscope_menu

router = Router()

# Команда из главного меню
@router.message(F.text == "🔮 Гороскопы")
async def horoscope_main(message: Message):
    await message.answer("🔮 Выберите тип гороскопа:", reply_markup=horoscope_menu())

# Обработка нажатий кнопок
@router.callback_query(F.data.startswith("horoscope_"))
async def horoscope_choice(callback: CallbackQuery):
    choice = callback.data
    if choice == "horoscope_day":
        await callback.message.answer("🔮 Ваш гороскоп на день: [тут будет текст]")
    elif choice == "horoscope_week":
        await callback.message.answer("🗓️ Ваш гороскоп на неделю: [тут будет текст]")
    elif choice == "horoscope_general":
        await callback.message.answer("🌌 Ваш общий гороскоп: [тут будет текст]")

    await callback.answer()

from aiogram import Router, F
from aiogram.types import Message

router = Router()

@router.message(F.text == "🌟 Гороскопы")
async def show_horoscope_menu(message: Message):
    """Меню гороскопов (пока базовое сообщение)."""
    await message.answer("🌌 Гороскопы в разработке! Скоро вы сможете узнать свой прогноз.")
