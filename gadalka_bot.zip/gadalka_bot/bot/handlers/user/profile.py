from aiogram import Router, F
from aiogram.types import Message
from bot.keyboards.main_menu import get_profile_menu

router = Router()

@router.message(F.text == "👤 Профиль")
async def show_profile_menu(message: Message):
    """Вывод основного меню профиля."""
    await message.answer(
        "Ваш профиль. Выберите нужное действие:",
        reply_markup=get_profile_menu()
    )