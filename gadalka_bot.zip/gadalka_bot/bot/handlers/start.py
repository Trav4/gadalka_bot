from aiogram import Router, F
from aiogram.types import Message
from bot.keyboards.main_menu import get_main_menu

router = Router()

# Обработчик команды /start
@router.message(F.text == "/start")
async def start_command(message: Message):
    """Приветственное сообщение и вызов главного меню."""
    await message.answer(
        "Добро пожаловать! Выберите нужную функцию из меню ниже:",
        reply_markup=get_main_menu()
    )

# Обработчик кнопки "❓ Помощь"
@router.message(F.text == "❓ Помощь")
async def help_command(message: Message):
    """Сообщение с пояснением о боте."""
    await message.answer(
        "Этот бот может помочь вам с:\n\n"
        "- 🔮 Расклады Таро\n"
        "- 🗺️ Натальной картой\n"
        "- 📜 Матрицей судьбы\n"
        "- 🌟 Гороскопами\n"
        "- и многим другим!\n\n"
        "Выберите интересующий раздел. Для возврата в главное меню нажмите кнопку 'Главное меню'.",
        reply_markup=get_main_menu()
    )
