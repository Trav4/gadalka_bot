# import asyncio
# from aiogram import Router, F
# from aiogram.types import CallbackQuery, Message, FSInputFile
# from aiogram.fsm.context import FSMContext
#
# from bot.services.tarot_reading import perform_tarot_reading
# from bot.states.tarot_states import TarotReading
# from pathlib import Path
#
# TAROT_IMAGES_PATH = Path("gadalka_bot/bot/tarot_cards/images")
#
# router = Router()
#
# @router.callback_query(F.data.startswith("t_crossroads"))
# async def tarot_reading_start(callback: CallbackQuery, state: FSMContext):
#     reading_type = callback.data
#     await state.update_data(reading_type=reading_type)  # Сохраняем тип расклада
#     await state.set_state(TarotReading.waiting_for_question)  # Ждем вопрос
#
#     await callback.message.answer(
#         "Ты стоишь на развилке дорог, и каждая из них ведёт к своему предназначению. Этот расклад поможет найти ответ, какой путь выбрать.\n\n"
#     "Задай вопрос, а карты помогут сделать правильный выбор\n"
#     "*Примеры вопросов:*\n"
#     "• Какое решение принесёт наилучший исход?\n"
#     "• Что ожидает меня, если я выберу этот путь?\n"
#     "• Какие опасности скрыты в моих решениях?",
#         parse_mode="Markdown"
#     )
#     await callback.answer()
#
# # Получение вопроса и проведение расклада
# @router.message(TarotReading.waiting_for_question)
# async def tarot_reading_continue(message: Message, state: FSMContext):
#     data = await state.get_data()
#     reading_type = data.get("reading_type")
#     user_question = message.text
#
#     await message.answer("✨ Мудрые силы Таро собираются для предсказания... 🔮")
#
#     reading_result = await perform_tarot_reading(reading_type, user_question)
#
#     for card in reading_result:
#         file_name = card['card_name']
#         if not file_name.endswith('.jpg'):
#             file_name += '.jpg'
#
#         card_name_readable = file_name.replace('_', ' ').replace('.jpg', '').title()
#
#         image_path = TAROT_IMAGES_PATH / file_name
#
#         caption = f"🃏 Карта: *{card_name_readable}* {'(Перевёрнутая)' if card['reversed'] else ''}"
#
#         try:
#             input_file = FSInputFile(str(image_path))
#             await message.answer_photo(photo=input_file, caption=caption, parse_mode="Markdown")
#             await asyncio.sleep(1)  # Пауза для красоты
#             await message.answer(card['prophecy'], parse_mode="Markdown")  # <<< ВОТ ТУТ ПРОРОЧЕСТВО
#
#         except FileNotFoundError:
#             await message.answer(
#                 f"⚠️ Карта *{card_name_readable}* не найдена. Вот твоё пророчество:\n\n{card['prophecy']}",
#                 parse_mode="Markdown"
#             )
#
#         await asyncio.sleep(2)
#
#     await message.answer(
#          "🔮 Путь сквозь Арканы пройден. Карты открыли то, что было сокрыто.\n"
#          "Пусть мудрость Таро ведёт тебя дальше. Твоя колдунья ТУММИМ — рядом, когда ты готов слушать. ")
#     await state.clear()
