# import asyncio
# from pathlib import Path
# from aiogram import Router, F
# from aiogram.types import CallbackQuery, Message
# from aiogram.fsm.context import FSMContext
# from bot.states.tarot_states import TarotReading
# from pathlib import Path
#
# TAROT_IMAGES_PATH = Path("gadalka_bot/bot/tarot_cards/images")
#
# router = Router()
#
# @router.callback_query(F.data.startswith("t_cosmos"))
# async def tarot_reading_start(callback: CallbackQuery, state: FSMContext):
#     reading_type = callback.data
#     await state.update_data(reading_type=reading_type)  # Сохраняем тип расклада
#     await state.set_state(TarotReading.waiting_for_question)  # Ждем вопрос
#
#     await callback.message.answer(
#         "Созвездия распахнутся перед тобой, рассказав о магии зодиакального круга. Этот расклад отвечает на вопросы о твоей жизни в связи с космическим предназначением.\n\n"
#     "Сформулируй вопрос о своём большом пути или влиянии звёзд.\n\n"
#     "*Примеры вопросов:*\n"
#     "• Какие энергии зодиака сейчас влияют на меня?\n"
#     "• Что говорит моя натальная карта?\n"
#     "• Какое влияние планет ждать в ближайшее время?",
#         parse_mode="Markdown"
#     )
#     await callback.answer()
#
# # Получение вопроса и проведение расклада
# @router.message(TarotReading.waiting_for_question)
# async def tarot_reading_continue(message: Message, state: FSMContext):
#     data = await state.get_data()
#     reading_type = data.get("reading_type")
#     user_question = message.text
#
#     await message.answer("✨ Мудрые силы Таро собираются для предсказания... 🔮")
#
#     reading_result = await perform_tarot_reading(reading_type, user_question)
#
#     for card in reading_result:
#         file_name = card['card_name']
#         if not file_name.endswith('.jpg'):
#             file_name += '.jpg'
#
#         card_name_readable = file_name.replace('_', ' ').replace('.jpg', '').title()
#
#         image_path = TAROT_IMAGES_PATH / file_name
#
#         caption = f"🃏 Карта: *{card_name_readable}* {'(Перевёрнутая)' if card['reversed'] else ''}"
#
#         try:
#             input_file = FSInputFile(str(image_path))
#             await message.answer_photo(photo=input_file, caption=caption, parse_mode="Markdown")
#             await asyncio.sleep(1)  # Пауза для красоты
#             await message.answer(card['prophecy'], parse_mode="Markdown")  # <<< ВОТ ТУТ ПРОРОЧЕСТВО
#
#         except FileNotFoundError:
#             await message.answer(
#                 f"⚠️ Карта *{card_name_readable}* не найдена. Вот твоё пророчество:\n\n{card['prophecy']}",
#                 parse_mode="Markdown"
#             )
#
#         await asyncio.sleep(2)
#
#     await message.answer(
#          "🔮 Путь сквозь Арканы пройден. Карты открыли то, что было сокрыто.\n"
#          "Пусть мудрость Таро ведёт тебя дальше. Твоя колдунья ТУММИМ — рядом, когда ты готов слушать. ")
#     await state.clear()
