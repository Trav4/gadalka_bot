import asyncio
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, FSInputFile
from aiogram.fsm.context import FSMContext
from aiogram.utils.keyboard import InlineKeyboardBuilder
from bot.services.tarot_reading import perform_tarot_reading
from bot.states.tarot_states import TarotReading
from pathlib import Path


TAROT_IMAGES_PATH = Path("gadalka_bot/bot/tarot_cards/images")  # Replace with the actual path to the tarot images folder

router = Router()

# Клавиатура под ответом
def under_answer_tarot_menu():
    buttons_data = [
        {"text": "🔙 Назад", "callback_data": "get_tarot_menu"},
        {"text": "🏠 Главное меню", "callback_data": "back_to_main_menu"},
    ]

    builder = InlineKeyboardBuilder()
    for button in buttons_data:
        builder.button(text=button["text"], callback_data=button["callback_data"])
    builder.adjust(3)

    return builder.as_markup()

@router.callback_query(F.data.startswith("t_oracle"))
async def tarot_reading_start(callback: CallbackQuery, state: FSMContext):
    reading_type = callback.data
    await state.update_data(reading_type=reading_type)  # Сохраняем тип расклада
    await state.set_state(TarotReading.waiting_for_question)  # Ждем вопрос

    await callback.message.answer(
            "🔮 Введите ваш вопрос для великой гадалки ТУММИМ.\n"
        "_Пожалуйста, сформулируйте чёткий, ясный и глубокий вопрос._\n\n"
        "Примеры:\n"
        "• Что ждёт меня в ближайшем будущем?\n"
        "• Как будет развиваться моё новое дело?\n"
        "• Каковы намерения человека по отношению ко мне?",
        parse_mode="Markdown"
    )
    await callback.answer()

# Получение вопроса и проведение расклада
@router.message(TarotReading.waiting_for_question)
async def tarot_reading_continue(message: Message, state: FSMContext):
    data = await state.get_data()
    reading_type = data.get("reading_type")
    user_question = message.text

    await message.answer("✨ Мудрые силы Таро собираются для предсказания... 🔮")

    reading_result = await perform_tarot_reading(reading_type, user_question)

    for card in reading_result:
        file_name = card['card_name']
        if not file_name.endswith('.jpg'):
            file_name += '.jpg'


        card_name_readable = file_name.replace('_', ' ').replace('.jpg', '').title()

        image_path = TAROT_IMAGES_PATH / file_name

        caption: str = f"🃏 Карта: *{card_name_readable}* {'(Перевёрнутая)' if card['reversed'] else ''}"

        try:
            input_file = FSInputFile(str(image_path))
            await message.answer_photo(photo=input_file, caption=caption, parse_mode="Markdown")
            await asyncio.sleep(1)  # Пауза для красоты
            await message.answer(card['prophecy'], parse_mode="Markdown")  # <<< ВОТ ТУТ ПРОРОЧЕСТВО

        except FileNotFoundError:
            await message.answer(
                f"⚠️ Карта *{card_name_readable}* не найдена. Вот твоё пророчество:\n\n{card['prophecy']}",
                parse_mode="Markdown"
            )

        await asyncio.sleep(2)

    await message.answer(
         "🔮 Путь сквозь Арканы пройден. Карты открыли то, что было сокрыто.\n"
         "Пусть мудрость Таро ведёт тебя дальше. Твоя колдунья ТУММИМ — рядом, когда ты готов слушать. ")
    await state.clear()
