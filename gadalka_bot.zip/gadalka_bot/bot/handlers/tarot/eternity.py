# import asyncio
# from aiogram import Router, F
# from aiogram.types import CallbackQuery, Message, FSInputFile
# from aiogram.fsm.context import FSMContext
# from aiogram.utils.keyboard import InlineKeyboardBuilder
#
# from bot.services.tarot_reading import perform_tarot_reading
# from bot.states.tarot_states import TarotReading
# from pathlib import Path
#
#
# TAROT_IMAGES_PATH = Path("gadalka_bot/bot/tarot_cards/images")
#
# router = Router()
#
# # Клавиатура под ответом
# def under_answer_tarot_menu():
#     buttons_data = [
#         {"text": "🔙 Назад", "callback_data": "get_tarot_menu"},
#         {"text": "🏠 Главное меню", "callback_data": "back_to_main_menu"},
#     ]
#
# @router.callback_query(F.data.startswith("t_eternity"))
# async def tarot_reading_start(callback: CallbackQuery, state: FSMContext):
#     reading_type = callback.data
#     await state.update_data(reading_type=reading_type)  # Сохраняем тип расклада
#     await state.set_state(TarotReading.waiting_for_question)  # Ждем вопрос
#
#     await callback.message.answer(
#         "Перед тобой открываются три великих врата: Прошлое, Настоящее и Будущее. Этот расклад позволяет понять, как прошлое влияет на настоящее и какое будущее ожидает тебя Мой Друг.\n\n"
#      "Сформулируй свой вопрос, чтобы рWазгадать эту взаимосвязь. Используй подсказку:\n\n"
#      "• Как моё прошлое мешает двигаться вперёд?\n"
#      "• Что важно знать о настоящем моменте?\n"
#         "• Какое будущее меня ждёт, если я продолжу этот путь?",
#         parse_mode="Markdown",
#     )
# await callback.answer()
#
# # Получение вопроса и проведение расклада
# @router.message(TarotReading.waiting_for_question)
# async def tarot_reading_continue(message: Message, state: FSMContext):
#     data = await state.get_data()
#     reading_type = data.get("reading_type")
#     user_question = message.text
#
#     await message.answer("✨ Мудрые силы Таро собираются для предсказания... 🔮")
#
#     reading_result = await perform_tarot_reading(reading_type, user_question)
#
#     for card in reading_result:
#         file_name = card['card_name']
#         if not file_name.endswith('.jpg'):
#             file_name += '.jpg'
#
#         card_name_readable = file_name.replace('_', ' ').replace('.jpg', '').title()
#
#         image_path = TAROT_IMAGES_PATH / file_name
#
#         caption = f"🃏 Карта: *{card_name_readable}* {'(Перевёрнутая)' if card['reversed'] else ''}"
#
#         try:
#             input_file = FSInputFile(str(image_path))
#             await message.answer_photo(photo=input_file, caption=caption, parse_mode="Markdown")
#             await asyncio.sleep(1)  # Пауза для красоты
#             await message.answer(card['prophecy'], parse_mode="Markdown")  # <<< ВОТ ТУТ ПРОРОЧЕСТВО
#
#         except FileNotFoundError:
#             await message.answer(
#                 f"⚠️ Карта *{card_name_readable}* не найдена. Вот твоё пророчество:\n\n{card['prophecy']}",
#                 parse_mode="Markdown"
#             )
#
#         await asyncio.sleep(2)
#
#     await message.answer(
#          "🔮 Путь сквозь Арканы пройден. Карты открыли то, что было сокрыто.\n"
#          "Пусть мудрость Таро ведёт тебя дальше. Твоя колдунья ТУММИМ — рядом, когда ты готов слушать. ")
#     await state.clear()
import asyncio
from pathlib import Path

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message, FSInputFile, InputMediaPhoto

from bot.services.tarot_reading import perform_tarot_reading
from bot.states.tarot_states import TarotReading

TAROT_IMAGES_PATH = Path("gadalka_bot/bot/tarot_cards/images")

router = Router()

# Клавиатура под ответом
def under_answer_tarot_menu():
    buttons_data = [
        {"text": "🔙 Назад", "callback_data": "get_tarot_menu"},
        {"text": "🏠 Главное меню", "callback_data": "back_to_main_menu"},
    ]

@router.callback_query(F.data.startswith("t_eternity"))
async def tarot_reading_start(callback: CallbackQuery, state: FSMContext):
    reading_type = callback.data
    await state.update_data(reading_type=reading_type)  # Сохраняем тип расклада
    await state.set_state(TarotReading.waiting_for_question)  # Ждем вопрос

    await callback.message.answer(
        "Перед тобой открываются три великих врата: Прошлое, Настоящее и Будущее. Этот расклад позволяет понять, как прошлое влияет на настоящее и какое будущее ожидает тебя Мой Друг.\n\n"
        "Сформулируй свой вопрос, чтобы разгадать эту взаимосвязь. Используй подсказку:\n\n"
        "• Как моё прошлое мешает двигаться вперёд?\n"
        "• Что важно знать о настоящем моменте?\n"
        "• Какое будущее меня ждёт, если я продолжу этот путь?",
        parse_mode="Markdown",
    )
    await callback.answer()

@router.message(TarotReading.waiting_for_question)
async def tarot_reading_continue(message: Message, state: FSMContext):
    data = await state.get_data()
    reading_type = data.get("reading_type")
    user_question = message.text

    await message.answer("✨ Мудрые силы Таро собираются для предсказания... 🔮")

    reading_result = await perform_tarot_reading(reading_type, user_question)

    media = []
    prophecies = []

    for idx, card in enumerate(reading_result):
        file_name = card['card_name']
        if not file_name.endswith('.jpg'):
            file_name += '.jpg'

        card_name_readable = file_name.replace('_', ' ').replace('.jpg', '').title()
        image_path = TAROT_IMAGES_PATH / file_name
        caption = f"🃏 Карта: *{card_name_readable}* {'(Перевёрнутая)' if card['reversed'] else ''}"

        try:
            input_file = FSInputFile(str(image_path))

            if idx == 0:
                media.append(InputMediaPhoto(media=input_file, caption=caption, parse_mode="Markdown"))
            else:
                media.append(InputMediaPhoto(media=input_file))

            prophecies.append(f"*{card_name_readable}:*\n{card['prophecy']}")

        except FileNotFoundError:
            await message.answer(f"⚠️ Карта *{card_name_readable}* не найдена.")
            prophecies.append(f"*{card_name_readable}:*\n{card['prophecy']}")

    if media:
        await message.bot.send_media_group(chat_id=message.chat.id, media=media)
        await asyncio.sleep(1)

    await message.answer("\n\n".join(prophecies), parse_mode="Markdown")

    await message.answer(
        "🔮 Путь сквозь Арканы пройден. Карты открыли то, что было сокрыто.\n"
        "Пусть мудрость Таро ведёт тебя дальше. Твоя колдунья ТУММИМ — рядом, когда ты готов слушать."
    )

    await state.clear()
