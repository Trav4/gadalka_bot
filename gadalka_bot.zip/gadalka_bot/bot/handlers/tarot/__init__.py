from aiogram import Router

tarot_router = Router()
__all__ = ["tarot_router"]