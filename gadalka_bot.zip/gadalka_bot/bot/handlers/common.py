# bot/handlers/common.py

from aiogram import Router, F
from aiogram.types import CallbackQuery


router = Router()

# @router.callback_query(F.data.startswith())
# async def tarot_reading_start(callback: CallbackQuery):
#     print(f"🔮 Начат расклад Оракула. Пользователь: {callback.from_user.id}")



