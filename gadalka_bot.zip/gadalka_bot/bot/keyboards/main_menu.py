from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

router = Router()

# Главное меню
def get_main_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="🃏 Расклады Таро", callback_data="tarot_menu")
    builder.button(text="♈ Гороскоп", callback_data="horoscope_menu")
    builder.button(text="🗺️ Натальная карта", callback_data="natal_menu")
    builder.button(text="🧮 Матрица судьбы", callback_data="destiny_menu")
    builder.button(text="💬 Совет дня", callback_data="sugest_menu")
    builder.button(text="👤 Профиль и подписка", callback_data="profile_menu")
    builder.button(text="❓ Помощь", callback_data="menu_help")
    builder.adjust(2)
    return builder.as_markup()

# Меню Таро
def get_tarot_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="Глас Оракула — пророчество в одном знаке", callback_data="t_oracle")
    builder.button(text="Три Врата Вечности — открой прошлое, настоящее и будущее", callback_data="t_eternit")
    builder.button(text="Перекрёсток Судеб — выбор дорог и путей", callback_data="t_crossroads")
    builder.button(text="Кельтский Завет — великий ключ понимания бытия", callback_data="t_legacy")
    builder.button(text="Ключ Удачи — открой врата к благословению", callback_data="t_fortune")
    builder.button(text="Башня Откровений — путь восхождения к истине", callback_data="t_ascensione")
    builder.button(text="Круг Великого Неба — звезды шепчут твою судьбу", callback_data="t_cosmos")
    builder.button(text="Зеркала Сердец — тайные нити любви и разлуки", callback_data="t_bond")
    builder.button(text="Вестник Ответа — да или нет в голосе вселенной", callback_data="t_whisper")
    builder.button(text="Печать Кармы — испытание для вознесения души", callback_data="t_destiny")
    builder.button(text="🔙 Назад", callback_data="back_to_main_menu")
    builder.adjust(1)
    return builder.as_markup()

# Меню Гороскопа
def get_horoscope_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="🔮 Гороскоп на день", callback_data="horoscope_day")
    builder.button(text="🗓️ Гороскоп на неделю", callback_data="horoscope_week")
    builder.button(text="🌌 Общий гороскоп", callback_data="horoscope_general")
    builder.button(text="🔙 Назад", callback_data="back_to_main_menu")
    builder.adjust(1)
    return builder.as_markup()

# Меню Натальной карты
def get_natal_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="🌀 Создать Натальную Карту", callback_data="natal_create")
    builder.button(text="🌀 Консультация по нотальной карте", callback_data="natal_consult")
    builder.button(text="🔙 Назад", callback_data="back_to_main_menu")
    builder.adjust(1)
    return builder.as_markup()

# Меню Матрицы судьбы
def get_destiny_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="🧿 Личная", callback_data="destiny_personal")
    builder.button(text="💞 Совместимость", callback_data="destiny_compatibility")
    builder.button(text="👶 Детская", callback_data="destiny_child")
    builder.button(text="🔙 Назад", callback_data="back_to_main_menu")
    builder.adjust(1)
    return builder.as_markup()

# Меню Профиля
def get_sugest_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="💳 Спросить совет", callback_data="sugest1")
  # builder.button(text="📜 Ежедневное предсказание", callback_data="sugets2")
    builder.button(text="🔙 Назад", callback_data="back_to_main_menu")
    builder.adjust(1)
    return builder.as_markup()




# Меню Профиля
def get_profile_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="💳 Пополнить баланс", callback_data="profile_topup")
    builder.button(text="📜 История пополнений", callback_data="profile_history")
    builder.button(text="🎟️ Подписки", callback_data="profile_subscriptions")
    builder.button(text="🔙 Назад", callback_data="back_to_main_menu")
    builder.adjust(1)
    return builder.as_markup()


# Обработчики callback-кнопок

# Обработчики кнопок назад
@router.callback_query(F.data == "back_to_main_menu")
async def back_to_main(callback: CallbackQuery):
    await callback.message.edit_text("🏠 Главное меню:", reply_markup=get_main_menu())
    await callback.answer()

@router.callback_query(F.data == "tarot_menu")
async def tarot_menu(callback: CallbackQuery):
    await callback.message.edit_text("🔮 Выберите расклад:", reply_markup=get_tarot_menu())
    await callback.answer()


@router.callback_query(F.data == "horoscope_menu")
async def horoscope_menu(callback: CallbackQuery):
    await callback.message.edit_text("♈ Меню Гороскопа", reply_markup=get_horoscope_menu())
    await callback.answer()

@router.callback_query(F.data == "natal_menu")
async def natal_menu(callback: CallbackQuery):
    await callback.message.edit_text("🗺️ Натальная карта", reply_markup=get_natal_menu())
    await callback.answer()

@router.callback_query(F.data == "destiny_menu")
async def destiny_menu(callback: CallbackQuery):
    await callback.message.edit_text("🧮 Матрица судьбы", reply_markup=get_destiny_menu())
    await callback.answer()

@router.callback_query(F.data == "sugest_menu")
async def sugest_menu(callback: CallbackQuery):
    await callback.message.edit_text("🔮 Ищешь совета путник?", reply_markup=get_sugest_menu())
    await callback.answer()

@router.callback_query(F.data == "profile_menu")
async def profile_menu(callback: CallbackQuery):
    await callback.message.edit_text("👤 Профиль", reply_markup=get_profile_menu())
    await callback.answer()


# Клавиатура под ответом
   # def under_answer_sugest_menu():
    #   builder.button(text="🔙 Назад", callback_data="sugest_menu")
    #    builder.button(text="🔁 Спросить ещё", callback_data="sugest1")
    #    builder.button(text="🏠 Главное меню", callback_data="back_to_main_menu")
    #builder.adjust(3)
   # return builder.as_markup()

