from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from typing import Any, Optional, Union
from aiogram.filters.callback_data import CallbackData
from aiogram.types import (
    WebAppInfo, LoginUrl, SwitchInlineQueryChosenChat,
    CopyTextButton, CallbackGame
)

from bot.keyboards.base_keyboard_builder import KeyboardBuilder


class InlineKeyboardBuilder(KeyboardBuilder[InlineKeyboardButton]):
    max_width: int = 8
    min_width: int = 1
    max_buttons: int = 100

    def __init__(self, markup: Optional[list[list[InlineKeyboardButton]]] = None) -> None:
        super().__init__(button_type=InlineKeyboardButton, markup=markup)

    def button(
        self,
        *,
        text: str,
        url: Optional[str] = None,
        callback_data: Optional[Union[str, CallbackData]] = None,
        web_app: Optional[WebAppInfo] = None,
        login_url: Optional[LoginUrl] = None,
        switch_inline_query: Optional[str] = None,
        switch_inline_query_current_chat: Optional[str] = None,
        switch_inline_query_chosen_chat: Optional[SwitchInlineQueryChosenChat] = None,
        copy_text: Optional[CopyTextButton] = None,
        callback_game: Optional[CallbackGame] = None,
        pay: Optional[bool] = None,
        **kwargs: Any,
    ) -> "InlineKeyboardBuilder":
        return self._button(
            text=text,
            url=url,
            callback_data=callback_data,
            web_app=web_app,
            login_url=login_url,
            switch_inline_query=switch_inline_query,
            switch_inline_query_current_chat=switch_inline_query_current_chat,
            switch_inline_query_chosen_chat=switch_inline_query_chosen_chat,
            copy_text=copy_text,
            callback_game=callback_game,
            pay=pay,
            **kwargs,
        )

    def as_markup(self, **kwargs: Any) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(inline_keyboard=self.export())
