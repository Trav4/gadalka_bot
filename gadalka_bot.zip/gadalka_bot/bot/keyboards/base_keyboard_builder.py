from abc import ABC
from copy import deepcopy
from itertools import chain, cycle as repeat_all
from typing import (
    Any, Generator, Generic, Iterable, List,
    Optional, Type, TypeVar, Union,
)
from aiogram.filters.callback_data import CallbackData
from aiogram.types import (
    InlineKeyboardButton, KeyboardButton,
    InlineKeyboardMarkup, ReplyKeyboardMarkup
)

ButtonType = TypeVar("ButtonType", InlineKeyboardButton, KeyboardButton)
T = TypeVar("T")


def repeat_last(items: Iterable[T]) -> Generator[T, None, None]:
    items_iter = iter(items)
    try:
        value = next(items_iter)
    except StopIteration:
        return
    yield value
    finished = False
    while True:
        if not finished:
            try:
                value = next(items_iter)
            except StopIteration:
                finished = True
        yield value


class KeyboardBuilder(Generic[ButtonType], ABC):
    max_width: int = 0
    min_width: int = 0
    max_buttons: int = 0

    def __init__(self, button_type: Type[ButtonType], markup: Optional[List[List[ButtonType]]] = None) -> None:
        if not issubclass(button_type, (InlineKeyboardButton, KeyboardButton)):
            raise ValueError(f"Button type {button_type} not allowed")
        self._button_type = button_type
        self._markup = markup or []
        self._validate_markup(self._markup)

    @property
    def buttons(self) -> Generator[ButtonType, None, None]:
        yield from chain.from_iterable(self.export())

    def _validate_button(self, button: ButtonType) -> bool:
        if not isinstance(button, self._button_type):
            raise ValueError(f"{button!r} must be of type {self._button_type.__name__}")
        return True

    def _validate_buttons(self, *buttons: ButtonType) -> bool:
        return all(map(self._validate_button, buttons))

    def _validate_row(self, row: List[ButtonType]) -> bool:
        if len(row) > self.max_width:
            raise ValueError(f"Row too long (max: {self.max_width})")
        self._validate_buttons(*row)
        return True

    def _validate_markup(self, markup: List[List[ButtonType]]) -> bool:
        total = sum(len(row) for row in markup)
        if total > self.max_buttons:
            raise ValueError(f"Too many buttons (max: {self.max_buttons})")
        for row in markup:
            self._validate_row(row)
        return True

    def _validate_size(self, size: Any) -> int:
        if not isinstance(size, int) or size < self.min_width or size > self.max_width:
            raise ValueError(f"Invalid row size: {size}")
        return size

    def export(self) -> List[List[ButtonType]]:
        return deepcopy(self._markup)

    def add(self, *buttons: ButtonType) -> "KeyboardBuilder[ButtonType]":
        self._validate_buttons(*buttons)
        markup = self.export()
        if markup and len(markup[-1]) < self.max_width:
            pos = self.max_width - len(markup[-1])
            markup[-1].extend(buttons[:pos])
            buttons = buttons[pos:]
        for i in range(0, len(buttons), self.max_width):
            markup.append(list(buttons[i:i + self.max_width]))
        self._markup = markup
        return self

    def row(self, *buttons: ButtonType, width: Optional[int] = None) -> "KeyboardBuilder[ButtonType]":
        width = self._validate_size(width or self.max_width)
        self._validate_buttons(*buttons)
        self._markup.extend([list(buttons[i:i + width]) for i in range(0, len(buttons), width)])
        return self

    def adjust(self, *sizes: int, repeat: bool = False) -> "KeyboardBuilder[ButtonType]":
        sizes = tuple(self._validate_size(size) for size in sizes) or (self.max_width,)
        sizes_iter = repeat_all(sizes) if repeat else repeat_last(sizes)
        size = next(sizes_iter)
        markup, row = [], []
        for button in self.buttons:
            if len(row) >= size:
                markup.append(row)
                row = []
                size = next(sizes_iter)
            row.append(button)
        if row:
            markup.append(row)
        self._markup = markup
        return self

    def _button(self, **kwargs: Any) -> "KeyboardBuilder[ButtonType]":
        if isinstance(callback_data := kwargs.get("callback_data"), CallbackData):
            kwargs["callback_data"] = callback_data.pack()
        button = self._button_type(**kwargs)
        return self.add(button)

    def as_markup(self, **kwargs: Any) -> Union[InlineKeyboardMarkup, ReplyKeyboardMarkup]:
        if self._button_type is KeyboardButton:
            return ReplyKeyboardMarkup(keyboard=self.export(), **kwargs)
        return InlineKeyboardMarkup(inline_keyboard=self.export(), **kwargs)

    def attach(self, builder: "KeyboardBuilder[ButtonType]") -> "KeyboardBuilder[ButtonType]":
        if not isinstance(builder, KeyboardBuilder):
            raise ValueError("Only KeyboardBuilder can be attached")
        if builder._button_type != self._button_type:
            raise ValueError("Mismatched button types")
        self._markup.extend(builder.export())
        return self
