from PIL import Image
import os

# Шлях до папки з зображеннями
input_folder = "input_images"
output_folder = "resized_images"
scale_factor = 0.5  # або замість цього можеш задати width, height вручну

# Створити папку для зменшених зображень, якщо її ще нема
os.makedirs(output_folder, exist_ok=True)

# Підтримувані формати
supported_formats = (".jpg", ".jpeg", ".png", ".webp")

for filename in os.listdir(input_folder):
    if filename.lower().endswith(supported_formats):
        img_path = os.path.join(input_folder, filename)
        with Image.open(img_path) as img:
            # Нові розміри
            new_size = (int(img.width * scale_factor), int(img.height * scale_factor))
            resized_img = img.resize(new_size, Image.LANCZOS)
            # Зберегти у вихідну папку
            resized_img.save(os.path.join(output_folder, filename))
            print(f"{filename} — готово")
