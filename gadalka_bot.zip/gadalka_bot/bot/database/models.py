from typing import Any, AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import Column, Integer, BigInteger, String, Date, Time, Boolean, TIMESTAMP, Float
from bot.config import DATABASE_URL

Base = declarative_base()

# Модель для таблицы users
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False)
    username = Column(String)
    full_name = Column(String)
    date_of_birth = Column(Date)
    birth_time = Column(Time)
    birth_city = Column(String)
    free_requests = Column(Integer, default=3)
    subscription = Column(String)
    subscription_expire = Column(TIMESTAMP)
    created_at = Column(TIMESTAMP)
    updated_at = Column(TIMESTAMP)
    is_active = Column(Boolean, default=True)
    birth_lat = Column(Float)
    birth_lon = Column(Float)
    admin = Column(Boolean, default=False, nullable=False)


# Инициализация асинхронного двигателя и сессии
engine = create_async_engine(DATABASE_URL, echo=False)
async_session = sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)

# Функция получения сессии
async def get_session() -> AsyncGenerator[Any, Any]:
    async with async_session() as session:
        assert isinstance(session, AsyncSession)
        yield session

        from sqlalchemy import Column, Integer, Text
        from app.models import Base

        class DailyAdvice(Base):
            __tablename__ = "daily_advice"

            id = Column(Integer, primary_key=True, autoincrement=True)
            text = Column(Text, nullable=False)