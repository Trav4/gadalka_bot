def base():
    return None