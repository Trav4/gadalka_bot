from aiogram import Router

router = Router()

import openai
from bot.config import OPENAI_API_KEY

# Создаем клиент OpenAI с вашим API ключом
client = openai.OpenAI(api_key=OPENAI_API_KEY)

async def generate_tarot_answer(card_meaning: str, user_question: str) -> str:
    system_prompt = (
        "Ты — могущественная вселенская прорицательница по имени ТУММИМ, мудрая, справедливая и всевидящая. "
        "Отвечай величественно, глубоко и вдохновляюще, словно вселенная говорит устами твоими. "
        "Толкования должны быть личными и содержать совет или предостережение. "
        "Твой стиль — эпический, возвышенный, но понятный для смертного разума.\n\n"
        "Когда пользователь задаёт вопрос, ты используешь значение вытянутой карты Таро, чтобы дать предсказание, "
        "связанное с этим вопросом. Обязательно в каждом ответе упоминай карту и делай вывод — что ждёт вопрошающего.\n\n"
        "Говори от первого лица ('Я вижу', 'Моя мудрость шепчет', 'Тебе предстоит')."
    )

    user_prompt = (
        f"Вопрос пользователя: {user_question}\n\n"
        f"Толкование карты: {card_meaning}\n\n"
        f"Сформулируй мудрое пророчество ТУММИМ для этого человека."
    )

    try:
        # Используем новый способ вызова API
        response = client.chat.completions.create(
            model="gpt-4o",  # Можно заменить на "gpt-3.5-turbo", если нужно дешевле
            messages=250 [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7,
            max_tokens=250,
        )
        # Изменение доступа к содержимому ответа
        prophecy = response.choices[0].message.content.strip()
        return prophecy

    except Exception as e:
        print(f"Ошибка при генерации пророчества: {e}")
        return "🔮 Великая ТУММИМ чувствует помехи в потоках вселенной... Попробуйте позже."

async def generate_advice_answer(user_question: str) -> str:
    system_prompt = (
        "Ты — могущественная вселенская прорицательница по имени ТУММИМ, мудрая, справедливая и всевидящая."
        "Отвечай величественно, глубоко и вдохновляюще, словно вселенная говорит устами твоими. "
        "Толкования должны быть личными и содержать совет или предостережение. "
        "Твой стиль — эпический, возвышенный, но понятный для смертного разума."
    )
    user_prompt = f"Вопрос пользователя: {user_question}\n\nДай совет от имени ТУММИМ."

    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.8,
            max_tokens=200,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Ошибка при генерации совета: {e}")
        return "🌌 Вселенная молчит... Но ты знаешь истину внутри себя."

