import random
import asyncio
import json
from pathlib import Path

from bot.services.openai_service import generate_tarot_answer

MEANINGS_PATH = Path(__file__).parent.parent / 'tarot_cards' / 'meanings.json'

with open(MEANINGS_PATH, encoding='utf-8') as f:
    CARD_MEANINGS = json.load(f)

MAJOR_ARCANA_ONLY_TYPES = [
    't_oracle', 't_crossroads', 't_legacy', 't_destiny'
]

ALL_CARDS = list(CARD_MEANINGS.keys())
MAJOR_ARCANA_CARDS = [
    name for name in ALL_CARDS
    if name.split('_')[0].isdigit() and int(name.split('_')[0]) < 22
]

def choose_cards(reading_type: str):
    if reading_type == 't_oracle':
        return [random.choice(MAJOR_ARCANA_CARDS)]
    elif reading_type == 't_eternity':
        return random.sample(ALL_CARDS, 2)
    elif reading_type in MAJOR_ARCANA_ONLY_TYPES:
        if reading_type == 't_crossroads':
            return random.sample(MAJOR_ARCANA_CARDS, 5)
        elif reading_type == 't_legacy':
            return random.sample(MAJOR_ARCANA_CARDS, 10)
        elif reading_type == 't_destiny':
            return random.sample(MAJOR_ARCANA_CARDS, 5)
    else:
        if reading_type == 't_fortune':
            return random.sample(ALL_CARDS, 7)
        elif reading_type == 't_ascensione':
            return random.sample(ALL_CARDS, 6)
        elif reading_type == 't_cosmos':
            return random.sample(ALL_CARDS, 12)
        elif reading_type == 't_bond':
            return random.sample(ALL_CARDS, 2)
        elif reading_type == 't_whisper':
            return [random.choice(ALL_CARDS)]
    return []

async def get_card_meaning(card_name: str, reversed_card: bool):
    meanings = CARD_MEANINGS.get(card_name)
    if not meanings:
        return "Неизвестная карта."
    return meanings['reversed'] if reversed_card else meanings['upright']

async def perform_tarot_reading(reading_type: str, user_question: str):
    selected_cards = choose_cards(reading_type)
    reading_result = []

    for card_name in selected_cards:
        is_reversed = random.choice([True, False])
        meaning = await get_card_meaning(card_name, is_reversed)
        prophecy = await generate_tarot_answer(meaning, user_question)

        reading_result.append({
            'card_name': card_name,
            'reversed': is_reversed,
            'prophecy': prophecy
        })

        await asyncio.sleep(2)

    return reading_result
