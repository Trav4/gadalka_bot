# aiogram v3 or v2 compatible code example
from aiogram import Bot, Dispatcher, types, F
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, Message
from aiogram.utils import executor
from aiogram.dispatcher.filters import Command

API_TOKEN = "YOUR_BOT_TOKEN"
ADMIN_IDS = [123456789]  # замените на реальные Telegram ID админов

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot=bot)

# --- User Panel Keyboard ---
def get_user_panel():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🔮 Получить гадание")],
            [KeyboardButton(text="🪄 Натальная карта"), KeyboardButton(text="🧬 Матрица судьбы")],
            [KeyboardButton(text="♈ Ежедневный гороскоп"), KeyboardButton(text="🗝 Совет дня")],
            [KeyboardButton(text="💰 Мой баланс"), KeyboardButton(text="👑 Подписка / Премиум")],
            [KeyboardButton(text="📜 История запросов"), KeyboardButton(text="⚙️ Настройки")],
            [KeyboardButton(text="📞 Поддержка")]
        ],
        resize_keyboard=True
    )

# --- Admin Panel Keyboard ---
def get_admin_panel():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📊 Статистика"), KeyboardButton(text="📬 Рассылка")],
            [KeyboardButton(text="👤 Список пользователей"), KeyboardButton(text="🚫 Бан пользователя")],
            [KeyboardButton(text="⬅️ Назад к меню")]
        ],
        resize_keyboard=True
    )

# --- Start Command Handler ---
@dp.message(F.text == "/start")
async def start_handler(message: Message):
    if message.from_user.id in ADMIN_IDS:
        await message.answer("Добро пожаловать, Админ! 👑", reply_markup=get_admin_panel())
    else:
        await message.answer("Добро пожаловать в Гадалку ТУММИМ 🌟\nВыберите нужную функцию:", reply_markup=get_user_panel())

# --- Example Handler for User Button Press ---
@dp.message(F.text == "🔮 Получить гадание")
async def handle_tarot(message: Message):
    await message.answer("Выберите расклад: \n1. Одна карта\n2. Три карты\n3. Кельтский крест")

# --- Admin Panel Handlers ---
@dp.message(F.text == "📊 Статистика")
async def stats_handler(message: Message):
    if message.from_user.id in ADMIN_IDS:
        await message.answer("📈 Статистика: \n- Пользователей: 1024\n- Запросов за сегодня: 321")

@dp.message(F.text == "📬 Рассылка")
async def broadcast_handler(message: Message):
    if message.from_user.id in ADMIN_IDS:
        await message.answer("Введите текст для рассылки всем пользователям.")
        # можно реализовать FSM для шага получения текста

@dp.message(F.text == "⬅️ Назад к меню")
async def back_to_menu(message: Message):
    if message.from_user.id in ADMIN_IDS:
        await message.answer("Возврат к пользовательскому меню.", reply_markup=get_user_panel())

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
