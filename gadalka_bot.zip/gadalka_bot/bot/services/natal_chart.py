import io
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from flatlib.chart import Chart
from flatlib.datetime import Datetime
from flatlib.geopos import GeoPos
from flatlib import const

async def generate_natal_chart(name: str, birth_date: str, birth_time: str, latitude: float, longitude: float):
    date = Datetime(birth_date, birth_time, '+00:00')  # фиксируем дату и время
    pos = GeoPos(latitude, longitude)
    chart = Chart(date, pos)

    description = f"🔮 *Натальная карта для {name}*:\n\n"
    for obj_name in const.LIST_OBJECTS:
        obj = chart.get(obj_name)
        description += "🌟 *{obj_name}*: {obj.sign} {obj.signlon:.2f}°\n"

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.set_facecolor('midnightblue')
    ax.set_xlim(-1.2, 1.2)
    ax.set_ylim(-1.2, 1.2)
    ax.axis('off')

    orbit = Circle((0, 0), 1, fill=False, edgecolor='white', linewidth=2)
    ax.add_artist(orbit)

    np.random.seed(42)
    stars_x = np.random.uniform(-1.2, 1.2, 120)
    stars_y = np.random.uniform(-1.2, 1.2, 120)
    ax.scatter(stars_x, stars_y, s=2, color='white', alpha=0.7)

    for obj_name in const.LIST_OBJECTS:
        obj = chart.get(obj_name)
        angle = (obj.signlon / 360.0) * 2 * np.pi
        x = 0.85 * np.cos(angle)
        y = 0.85 * np.sin(angle)
        ax.text(x, y, obj_name, color='white', fontsize=9, ha='center', va='center', weight='bold')

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', dpi=150)
    buf.seek(0)
    plt.close(fig)

    return description, buf
