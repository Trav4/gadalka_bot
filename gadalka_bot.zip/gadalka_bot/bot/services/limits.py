from bot.database.db import async_session
from bot.database.models import User
import sqlalchemy

async def check_free_requests(telegram_id: int) -> bool:
    async with async_session() as session:
        result = await session.execute(
            sqlalchemy.select(User).where(User.telegram_id == telegram_id)
        )
        user = result.scalar()

        if not user:
            return False
      #
       # if user.free_requests <= 0 and user.subscription == "Free":
        #    return False
        return True

async def decrement_free_request(telegram_id: int):
    async with async_session() as session:
        result = await session.execute(
            sqlalchemy.select(User).where(User.telegram_id == telegram_id)
        )
        user = result.scalar()

        if user and user.free_requests > 0:
            user.free_requests -= 1
            await session.commit()
